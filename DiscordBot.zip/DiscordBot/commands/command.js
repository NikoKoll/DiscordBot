const { NewsChannel } = require("discord.js")

module.exports = {
    name: 'command',
    description: "Embeds!",
    execute(message, args, Discord){
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#304381')
        .setTitle('Rules')
        .setDescription('this is a embed')
        .addFields(
            {name: 'Rule1', value: 'Be nice'}, 
            {name: 'Rule2', value: 'Be nice2'}

        )
        .setImage('https://www.formula1.com/content/fom-website/en/drivers/max-verstappen/_jcr_content/image.img.1024.medium.jpg/1616676511153.jpg')
        .setFooter('Check the Rules!!')

        message.channel.send(newEmbed);
    }

}